import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reactform',
  templateUrl: './reactform.page.html',
  styleUrls: ['./reactform.page.scss'],
})
export class ReactformPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
