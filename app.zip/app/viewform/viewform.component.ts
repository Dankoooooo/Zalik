// import { Component, OnInit } from '@angular/core';
// import { Subject } from '../myform/class/subject';

// @Component({
//   selector: 'app-viewform',
//   templateUrl: './viewform.component.html',
//   styleUrls: ['./viewform.component.scss'],
// })
// export class ViewformComponent implements OnInit {
//   show_update: boolean = false;
//   subjects: Subject[] = [];
//   constructor() { }
//   ngOnInit() {}
//   addSubject(event: any) {
//     if (event as Subject) {
//       let subject: Subject = event;
//       this.subjects.push(subject);
//       console.log(this.subjects);
//     }
//     else {
//       throw new Error("Type error");
//     }
//   }
//   update() { this.show_update = true; }
//   showUp(event: any) {
//     if (typeof event === "boolean") {
//       this.show_update = event;
//     }
//     else {
//       throw new Error("Type error");
//     }
//   }
//   update_save(event: any, i: number) {
//     if (event as Subject) {
//       this.subjects[i] = event;
//     }
//     else {
//       throw new Error("Type error");
//     }
//   }
// }
